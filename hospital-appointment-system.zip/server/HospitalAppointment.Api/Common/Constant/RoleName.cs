﻿namespace HospitalAppointment.Api.Common.Constants;

public static class RoleNames
{
    public const string Patient = "Patient";
    public const string Doctor = "Doctor";
    public const string Receptionist = "Receptionist";
    public const string PatientOrReceptionist = Patient + "," + Receptionist;
}